Locadora IPTV - Projeto pronto para deploy (Vite + React)

Como usar:

1. Instale dependências:
   npm install

2. Rodar em desenvolvimento:
   npm run dev

3. Build para produção:
   npm run build

Observações:
- Este projeto inclui HLS.js para reprodução de streams HLS.
- Tailwind CSS já está referenciado; rode a configuração padrão do Tailwind se quiser compilar estilos personalizados.
