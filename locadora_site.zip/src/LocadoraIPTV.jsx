import React, { useEffect, useRef, useState } from "react";
import Hls from "hls.js";

const PLAYLIST = [
  {
    id: "night",
    title: "Night of the Living Dead (1968)",
    group: "Terror",
    url: "https://archive.org/download/night_of_the_living_dead/night_of_the_living_dead_512kb.mp4",
    logo: "https://i.imgur.com/Xo4dbxJ.png",
  },
  {
    id: "nosferatu",
    title: "Nosferatu (1922)",
    group: "Terror",
    url: "https://archive.org/download/nosferatu_1922/nosferatu_1922.mp4",
    logo: "https://i.imgur.com/pT4N1Jh.png",
  },
  {
    id: "hisgirl",
    title: "His Girl Friday (1940)",
    group: "Comédia",
    url: "https://archive.org/download/his_girl_friday/his_girl_friday.mp4",
    logo: "https://i.imgur.com/pmga2Sf.png",
  },
  {
    id: "gulliver",
    title: "Gulliver's Travels (1939)",
    group: "Animação",
    url: "https://archive.org/download/Gullivers_Travels_1939/Gullivers_Travels_1939_512kb.m3u8",
    logo: "https://i.imgur.com/y7v6mUw.png",
  },
];

export default function LocadoraIPTV() {
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const [playlist] = useState(PLAYLIST);
  const [selected, setSelected] = useState(PLAYLIST[0]);
  const [query, setQuery] = useState("");
  const [groupFilter, setGroupFilter] = useState("All");

  useEffect(() => {
    attachStream(selected.url);
    return () => {
      destroyHls();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const destroyHls = () => {
    if (hlsRef.current) {
      try {
        hlsRef.current.destroy();
      } catch (e) {}
      hlsRef.current = null;
    }
  };

  const attachStream = (url) => {
    const video = videoRef.current;
    if (!video) return;
    destroyHls();

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = url;
      video.play().catch(() => {});
      return;
    }

    if (Hls.isSupported()) {
      const hls = new Hls();
      hlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function () {
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, function (event, data) {
        console.warn("Hls error", event, data);
      });
    } else {
      video.src = url;
    }
  };

  const groups = ["All", ...Array.from(new Set(playlist.map((p) => p.group)))];

  const filtered = playlist.filter((p) => {
    if (groupFilter !== "All" && p.group !== groupFilter) return false;
    if (!query) return true;
    return (
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.group.toLowerCase().includes(query.toLowerCase())
    );
  });

  const generateM3U = (items) => {
    const header = "#EXTM3U\n";
    const body = items
      .map(
        (it) =>
          `#EXTINF:-1 tvg-logo="${it.logo || ""}" group-title="${it.group}",${it.title}\n${it.url}`
      )
      .join("\n\n");
    return header + "\n" + body + "\n";
  };

  const downloadM3U = () => {
    const m3u = generateM3U(playlist);
    const blob = new Blob([m3u], { type: "audio/x-mpegurl" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "locadora_gigante.m3u";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Locadora IPTV — Gigante (Legal)</h1>
          <div>
            <button onClick={downloadM3U} className="px-3 py-1 bg-emerald-500 rounded">
              Baixar M3U
            </button>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section className="lg:col-span-2">
            <div className="bg-slate-800 rounded p-4">
              <video ref={videoRef} controls playsInline className="w-full rounded" style={{height:420}}/>
              <div className="mt-3 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold">{selected.title}</h2>
                  <p className="text-sm text-slate-300">{selected.group}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => attachStream(selected.url)} className="px-3 py-1 rounded bg-slate-700/50">Recarregar</button>
                  <a href={selected.url} target="_blank" rel="noreferrer" className="px-3 py-1 rounded bg-slate-700/50">Abrir fonte</a>
                </div>
              </div>
            </div>
          </section>

          <aside>
            <div className="bg-slate-800 rounded p-3 mb-4">
              <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Buscar título ou gênero..." className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700"/>
              <div className="mt-3 flex gap-2 overflow-x-auto">
                {groups.map(g => (
                  <button key={g} onClick={()=>setGroupFilter(g)} className={`px-3 py-1 rounded-full text-sm ${groupFilter===g ? 'bg-emerald-500':'bg-slate-700/40'}`}>{g}</button>
                ))}
              </div>
            </div>

            <div className="bg-slate-800 rounded p-3 max-h-[60vh] overflow-auto">
              <ul className="space-y-2">
                {filtered.map(item => (
                  <li key={item.id} onClick={()=>setSelected(item)} className={`flex gap-3 items-center p-2 rounded hover:bg-slate-700/40 cursor-pointer ${selected.id===item.id ? 'ring-2 ring-emerald-500':''}`}>
                    <img src={item.logo} alt="logo" className="w-12 h-8 object-cover rounded"/>
                    <div>
                      <div className="font-medium text-sm">{item.title}</div>
                      <div className="text-xs text-slate-400">{item.group}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </main>

        <footer className="mt-8 text-center text-slate-400 text-sm">
          Criado por ChatGPT — Locadora legal (domínio público).
        </footer>
      </div>
    </div>
  );
}
