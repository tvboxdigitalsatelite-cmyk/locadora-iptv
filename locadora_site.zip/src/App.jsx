import React from 'react'
import LocadoraIPTV from './LocadoraIPTV'

export default function App(){
  return <LocadoraIPTV />
}
